import { Component, OnInit } from '@angular/core';
import { MyServiceService, Mobile } from '../my-service.service';

@Component({
  selector: 'app-mobile-list',
  templateUrl: './mobile-list.component.html',
  styleUrls: ['./mobile-list.component.css']
})
export class MobileListComponent implements OnInit {
service:MyServiceService;
mobile:Mobile[]=[];
  constructor(service:MyServiceService) {
    this.service=service;
   }
   delete(mobId:number)
   {
     this.service.delete(mobId);
     this.mobile=this.service.getMobile();
   }
   column:string="mobId"; 
   order:boolean=true;
   sort(column:string){
    
     if(this.column==column )
     {
       this.order=!this.order;
     }else{
       this.order=true;
       this.column=column;
     }
   }

  ngOnInit() {
    this.service.fetchMobile();
    this.mobile=this.service.getMobile();

  }

}
