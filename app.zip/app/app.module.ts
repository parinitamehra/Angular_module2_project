import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClient, HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MobileListComponent } from './mobile-list/mobile-list.component';
import { MyServiceService } from './my-service.service';
import { FormsModule } from "@angular/forms";

import { OrderPipe } from './order.pipe';

@NgModule({
  declarations: [
    AppComponent,
    MobileListComponent,
   
    OrderPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,FormsModule
  ],
  providers: [HttpClient,MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
