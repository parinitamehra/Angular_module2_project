import { OrderPipe } from './order.pipe';

describe('OrderPipe', () => {
  it('create an instance', () => {
    const pipe = new OrderPipe();
    expect(pipe).toBeTruthy();
  });
});
