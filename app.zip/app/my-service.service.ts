import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  http: HttpClient;
  mobile: Mobile[] = [];
  constructor(http: HttpClient) {
    this.http = http;
  }

  fetched: boolean;
  fetchMobile() {


    this.http.get('./assets/Mobile.json').subscribe(data => {
      if (!this.fetched) {
        this.convert(data);
        this.fetched = true;
      }
    }
    );
  }

  convert(data: any) {
    for (let o of data) {
      let e = new Mobile(o.mobId, o.mobName, o.mobPrice);
      this.mobile.push(e);
    }

  }
  getMobile(): Mobile[] {
    return this.mobile;
  }
  delete(mobId: number) {
    let foundIndex: number = -1;
    for (let i = 0; i < this.mobile.length; i++) {
      let e = this.mobile[i];
      if (mobId == e.mobId) {
        foundIndex = i;
        break;
      }
    }
    this.mobile.splice(foundIndex, 1);
  }
  search(mobId:number):Mobile[]
  {
let resultDept:Mobile[]=[];
let o:Mobile;
var flag=0;
for(let i=0;i<this.mobile.length;i++)
{
  o=this.mobile[i];
  //console.log(o);
  if(mobId==o.mobId)
  {
    resultDept.push(o);
    alert(o.mobId + " " + o.mobName);
    flag=1;
    console.log(flag);
  }
}
if(flag==0)
{
  alert(mobId+ "dosen't exist");
}
return resultDept;
  }




}






export class Mobile {
  mobId: number;
  mobName: string;
  mobPrice: number;
  constructor(mobId: number, mobName: string, mobPrice: number) {
    this.mobId = mobId;
    this.mobName = mobName;
    this.mobPrice = mobPrice;
  }
}
