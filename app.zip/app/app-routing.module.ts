import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MobileListComponent } from './mobile-list/mobile-list.component';


const routes: Routes = [
{
  path:"mob",
  component:MobileListComponent
}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
